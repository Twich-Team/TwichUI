local _, P = ...
P.Build = { kind="development-only", format=1, commit="4fd74f4f76dce70921e261d324c94508e04e69c3", generator_sha256="aac78b6524890bc5300c05cd7eae4047833ee0fd0f2a96bdeb85ad204ca8e622", zlib_runtime="1.3.2", files={
  ["TwichUI_CodecProbe.toc"]="bff14816b3f920f870b0d74245333fc281841446bc8a40d239fc01760adaa426",
  ["Vectors.lua"]="8c389e43615b21a74d39c2b6ca32a775da7278c9e30dbe05774f4dbd598ed811",
  ["Engine.lua"]="4bfdc4d36456c40e6e9bbe434d314e730e9893f14144acfbfa7a92d781eb88a9",
  ["Probe.lua"]="b63eb48d39cf89bbcb2526b2dbe30158218fca07ccb231ca857e4883bd49c795",
} }
